## Vault (https://www.vaultproject.io) autocomplete plugin

- Adds autocomplete options for all vault commands.

####Show help for all commands
![General Help](http://i.imgur.com/yv5Db1r.png "Help for all commands")


####Create new Vault token
![Create token](http://i.imgur.com/xMegNgh.png "Create token")


####Enable audit backends
![Audit backends](http://i.imgur.com/fKLeiSF.png "Audit backends")



Crafted with <3 by Valentin Bud ([@valentinbud](https://twitter.com/valentinbud))