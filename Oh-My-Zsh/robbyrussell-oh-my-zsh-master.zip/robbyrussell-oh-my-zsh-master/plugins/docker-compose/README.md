# Docker-compose plugin for oh my zsh

A copy of the completion script from the [docker-compose](https://github.com/docker/compose/blob/master/contrib/completion/zsh/_docker-compose) git repo.

